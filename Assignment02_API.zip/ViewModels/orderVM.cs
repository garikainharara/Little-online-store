﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment02_API.Models;

namespace Assignment02_API.ViewModels
{
    public class orderVM
    {
        public List<basketProductVM> basketProducts { get; set; }
       
    }
}
