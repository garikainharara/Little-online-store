import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Tab1PageRoutingModule } from './tab1-routing.module';
import { HttpClientModule } from '@angular/common/http';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page {
  prods: any; 
  response: any;
 
  constructor(
    private httpClient: HttpClient
   ){
     this.getProductsList(); 
   }

  
   getProductsList() 
   {
    this.httpClient.get<any>('https://localhost:44379/api/product/getProductList').subscribe(
       response => {
         this.prods = response;
         
         return  response;       
       } 
     );
   }
   setBasket(id: number) 
   {
     
   
      var ids = new Array();  
      var quants = new Array();
    

     var q1 = id;
     var quant = parseInt((<HTMLInputElement>document.getElementById(q1.toString())).value);
      if(quant >0)
      {
       
        var itemsid = JSON.parse(localStorage.getItem('ids'));
        var itemsquants = JSON.parse(localStorage.getItem('quants'));

        if(itemsid!=null)
        {
          ids.push(id);
          quants.push(quant);
          for (let i=0; i<itemsid.length; i++)
          {
             ids.push(itemsid[i]) 
             quants.push(itemsquants[i]);
          }
         
          localStorage.setItem('ids', JSON.stringify(ids));
          localStorage.setItem('quants', JSON.stringify(quants));
        }
        else
        {
          ids.push(id);
          quants.push(quant);
          localStorage.setItem('ids', JSON.stringify(ids));
          localStorage.setItem('quants', JSON.stringify(quants));
        }
        
        ((<HTMLInputElement>document.getElementById(q1.toString())).value) = "0";
      }
      else{
       
      }
      
   }


}

