import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PipeTransform, Pipe } from '@angular/core';
import { OnInit } from '@angular/core';
import { NgZone } from '@angular/core';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit  {
  prods: any; 
  items: any;
  temp: any[];
  obj: any;
  orders :string[]=new Array();
  constructor(private httpClient: HttpClient, public toastController : ToastController) {
   
  }
  ngOnInit(): void {
    this.prods = null;
    this.items = null;
    this.temp =null;
    this.obj = null;
 
    this.ionViewWillEnter();
  }
  


  
  ionViewWillEnter ()
  {
    

    var itemsid = JSON.parse(localStorage.getItem('ids'));
    var itemsquants = JSON.parse(localStorage.getItem('quants'));

    
    var filters = JSON.parse(localStorage.getItem('filter'));
    this.httpClient.get<any>('https://localhost:44379/api/product/getProductList').subscribe(
      response => {
        this.prods = response;
        
        this.items = response.filter(person => itemsid.includes(person.productId));
       
        for(let i=0; i<this.items.length; i++)
        {
          this.items[i].productDescription = itemsquants[i];
        }
               
      } 
    );
    
  }
  deletes(id: number)
  {
      
    var itemsid = JSON.parse(localStorage.getItem('ids'));
    var itemsquants = JSON.parse(localStorage.getItem('quants'));
 
 
    const index = itemsid.indexOf(id);

    
    if (index > -1) {
      itemsid.splice(index, 1); // 2nd parameter means remove one item only
      itemsquants.splice(index,1) 
    }

    localStorage.setItem('ids', JSON.stringify(itemsid));
    localStorage.setItem('quants', JSON.stringify(itemsquants));

    this.ionViewWillEnter();
  }
  
  async presentToast() {
    const toast  = await this.toastController.create({
      message: 'Order Created',
      duration: 2000
    });
    var itemsid = JSON.parse(localStorage.getItem('ids'));
    if(itemsid.length!=0)
    {
      toast.present();
    }

  
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    var date = mm + '-' + dd + '-' + yyyy;

    //------------------------------------------------------
    localStorage.setItem('orders', JSON.stringify(this.orders));
    this.orders = JSON.parse(localStorage.getItem('orders'));
    var orderno = "Order #"+this.orders.length+" :"+date;
    if(this.orders.length==0)
    {
      this.orders.push(orderno);

      localStorage.setItem('orders', JSON.stringify(this.orders));
    }
    else{
      this.orders.push(orderno);
      localStorage.setItem('orders', JSON.stringify(this.orders));
    } 
   

   var alphas:number[]; 
   alphas = [];
   var itemsquants = null;
    localStorage.setItem('ids', JSON.stringify(alphas));
    localStorage.setItem('quants', JSON.stringify(alphas));
    this.ionViewWillEnter();
  }

}
